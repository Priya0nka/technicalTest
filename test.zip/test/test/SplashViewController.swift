//
//  SplashViewController.swift
//  test
//
//  Created by mac on 30/05/23.
//

import UIKit

class SplashViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
            let vc = UIStoryboard.init(name: "Main",
                                       bundle: Bundle.main)
                .instantiateViewController(withIdentifier: "ViewController")
            as? ViewController
            self.navigationController?.pushViewController(vc!,
                                                          animated: true)
        }
    }

}
