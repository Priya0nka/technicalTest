import UIKit

public protocol PopUpViewNewDelegate: AnyObject {
    func onTapLeftButton()
    func onTapRightButton()
}

class PopUpView: UIView {
    /*
     This class use for show Popup anywhere in the project
     */

    // MARK: - Single object instance
    class var sharedInstance: PopUpView {
        struct Singleton {
            static let instance = (UINib(nibName: "PopUpView",
                                         bundle: nil)).instantiate(withOwner: nil, options: nil)[0] as? PopUpView
        }
        return Singleton.instance ?? PopUpView()
    }
    weak var delegate: PopUpViewNewDelegate?

    // MARK: - IBOutlets
    @IBOutlet private weak var headerLabel: UILabel!
    @IBOutlet private weak var messageLabel: UILabel!
    @IBOutlet private weak var closeButton: UIButton!
    @IBOutlet private weak var leftButton: UIButton!
    @IBOutlet private weak var rightButton: UIButton!

    typealias Action = (() -> Void?)

    var rightButtonAction: Action?

    // MARK: - ButtonActions

    @IBAction private func onTapClose(_ sender: Any) {
        self.removeFromSuperview()
    }

    @IBAction private func onTapLeft(_ sender: Any) {
        onTapClose(self)
        delegate?.onTapLeftButton()
    }

    @IBAction private func onTapRight(_ sender: Any) {
        onTapClose(self)
        self.rightButtonAction?()
        delegate?.onTapRightButton()
    }

    // MARK: - Set popup layouts for set titles
    func setPopupLayout( headerTitle: String,
                         msg: String,
                         leftButtonTitle: String,
                         rightButtonTitle: String,
                         isCancel: Bool,
                         rightButtonAction: Action?) {
         DispatchQueue.main.async {
            self.rightButtonAction = rightButtonAction
            guard let viewController = self.topController() else { return }
          self.frame = viewController.view.frame
          viewController.view.addSubview(self)
         }
    }

    // MARK: - Open Functions
    // For show alertView
    class func showPopupViewAlert( headerTitle: String = "",
                                   msg: String = "",
                                   leftButtonTitle: String = "",
                                   rightButtonTitle: String = "",
                                   isCancel: Bool = false,
                                   tag: Int = 1,
                                   rightButtonAction: Action?) {
        PopUpView.sharedInstance.setPopupLayout( headerTitle: headerTitle,
                                                 msg: msg,
                                                 leftButtonTitle: leftButtonTitle,
                                                 rightButtonTitle: rightButtonTitle,
                                                 isCancel: isCancel,
                                                 rightButtonAction: rightButtonAction)
        PopUpView.sharedInstance.tag = tag
    }

     // For show validation alert
    class func showPopupViewValidation( headerTitle: String,
                                        array: [String],
                                        leftButtonTitle: String,
                                        rightButtonTitle: String,
                                        isCancel: Bool = false,
                                        rightButtonAction: Action?) {
        var msg = ""
        array.forEach { msg = "\(msg)\n- \($0)" }
        msg.removeFirst()
        PopUpView.sharedInstance.setPopupLayout( headerTitle: headerTitle,
                                                 msg: msg,
                                                 leftButtonTitle: leftButtonTitle,
                                                 rightButtonTitle: rightButtonTitle,
                                                 isCancel: isCancel,
                                                 rightButtonAction: rightButtonAction)
    }

    func topController() -> UIViewController? {
        if var topController = UIApplication.shared.keyWindow?.rootViewController {
            while let presentedViewController = topController.presentedViewController {
                topController = presentedViewController
            }
            return topController
        }
        return nil
    }

}
