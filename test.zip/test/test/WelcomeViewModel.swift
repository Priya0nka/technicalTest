//
//  WelcomeViewModel.swift
//  test
//
//  Created by mac on 30/05/23.
//

import Foundation

class WelcomeViewModel {

    private var welcomeArray = [WelcomeModel]()
    var offset = 1
    var pageLimit = 20
    var isAllDataLoaded = false

    func getCount() -> Int {
        self.welcomeArray.count
    }

    func getModel(_ at: Int) -> WelcomeModel {
        self.welcomeArray[at]
    }

    func selectModel(_ at: Int) {
        self.welcomeArray[at].isSelected.toggle()
    }

    func getCellIsSelectedOrNot(_ at: Int) -> Bool {
        self.welcomeArray[at].isSelected
    }
}


typealias RequestCompletion = (_ reply: String?,
                               _ response: [Dictionary<String,Any>]?,
                               _ error: Error?,
                               _ statuscode: Int?) -> Void

extension WelcomeViewModel {

    func requestWelcomeList(responseHandler: @escaping (_ success: Bool,
                                                       _ status: Int,
                                                       _ message: String) -> Void) {
        self.requestApiCall(urls: "https://picsum.photos/v2/list?page=\(self.offset)&limit=\(self.pageLimit)",
                            completion: { _, dictResponse, error, status in
            DispatchQueue.main.async {
                if status == 200 || status == 404 {
                    if let result = dictResponse {
                        let resultArray = result.map({ WelcomeModel($0 as? [String: Any] ?? [String: Any]()) })
                        if self.offset == 1 {
                            self.welcomeArray = resultArray
                        } else {
                            self.welcomeArray += resultArray
                        }
                        self.isAllDataLoaded = resultArray.count >= self.pageLimit
                    } else {
                        self.isAllDataLoaded = false
                    }
                    responseHandler(true, status ?? 0, "message")
                } else {
                    responseHandler(false, status ?? 0, "message")
                }
            }
        })
    }

    func requestApiCall(urls: String, completion: @escaping RequestCompletion) {
        guard let url = URL(string: urls) else { return }
        var request = URLRequest(url: url)
        // request.httpMethod = "GET"
        request.setValue("multipart/form-data", forHTTPHeaderField: "Content-Type")

        let task = URLSession.shared.dataTask(with: request) { data, response, err in
            var reply: String?
            var jsonData: [Dictionary<String,Any>]?
            var urlResponse: HTTPURLResponse?
            if let res: HTTPURLResponse = response as? HTTPURLResponse {
                urlResponse = res
            }
            if let data = data {
                do {
                    reply = String(data: data, encoding: String.Encoding.utf8)
                    if let data = reply?.data(using: .utf8) {
                        do {
                            if let jsonArray = try JSONSerialization.jsonObject(with: data, options : .allowFragments) as? [Dictionary<String,Any>]
                            {
                                DispatchQueue.main.async {
                                    completion(reply, jsonArray, err, urlResponse?.statusCode)
                                }
                               print(jsonArray) // use the json here
                            } else {
                                print("bad json")
                            }
                        } catch let error as NSError {
                            print(error)
                        }
                    }
                } catch {
                    DispatchQueue.main.async {
                        completion(reply, jsonData, err, urlResponse?.statusCode)
                    }
                }
            } else {
                completion(nil, nil, nil, 500)
            }
        }
        task.resume()
    }

}
