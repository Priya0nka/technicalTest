//
//  WelcomeTableViewCell.swift
//  test
//
//  Created by mac on 30/05/23.
//

import UIKit

class WelcomeTableViewCell: UITableViewCell {

    // MARK: - IBOutlet
    @IBOutlet private weak var checkBoxImageView: UIImageView!
    @IBOutlet private weak var profileImageView: UIImageView!
    @IBOutlet private weak var nameLabel: UILabel!
    @IBOutlet private weak var descriptionLabel: UILabel!

    // Variable
    private let select = UIImage(named: "circleRightBlack")
    private let unSelect = UIImage(named: "circleOutline")

    // MARK: - Helper
    func setCellData(data: WelcomeModel) {
        nameLabel.text = data.id
        descriptionLabel.text = data.author
        cellSelected(isSelected: data.isSelected)
        DispatchQueue.main.async {
           // self.profileImageView.image = self.getChampionThumbnailImage(urls: data.downloadURL)
        }
    }

    func cellSelected(isSelected: Bool) {
        if isSelected {
            checkBoxImageView.image = select
        } else {
            checkBoxImageView.image = unSelect
        }
    }

    func getChampionThumbnailImage(urls: String) -> UIImage {

        var image: UIImage!
        let urlString = urls
        guard let url = URL(string: urlString) else { return UIImage() }

        // Before, downloading the image, we check the cache to see if it exists and is stored.
        // If so, we can grab that image from the cache and avoid downloading it again.
        if let cachedImage = ImageCache.sharedImageCache.fetchImage(for: url) {
            image = cachedImage
            return image
        }

        let session = URLSession.shared

        let semaphore = DispatchSemaphore(value: 0)

        session.dataTask(with: url) {(data, response, error) in
            if error != nil {
                print("ERROR")
                semaphore.signal()
            }
            else {
                image = UIImage(data: data!)!
                // Once the image is successfully downloaded the first time, add it to
                // the cache for later retrieval
                ImageCache.sharedImageCache.add(image: image, for: url)
                semaphore.signal()
            }
        }.resume()

        semaphore.wait()
        session.finishTasksAndInvalidate()

        return image
    }
 
}

class ImageCache: NSObject {
    static let sharedImageCache = ImageCache()

    // Initialize cache, specifying that your key type is AnyObject
    // and your value type is AnyObject. This is because NSCache requires
    // class types, not value types so we can't use <URL, UIImage>

    let imageCache = NSCache<AnyObject, AnyObject>()

    // Here we store the image, with the url as the key
    func add(image: UIImage, for url: URL) {
        // we cast url as AnyObject because URL is not a class type, it's a value type
        imageCache.setObject(image, forKey: url as AnyObject)
    }

    // This allows us to access the image from cache with the URL as the key
    // (e.g. cache[URL])
    func fetchImage(for url: URL) -> UIImage? {
        var image: UIImage?

        // Casting url for the same reason as before, but we also want the result
        // as an image, so we cast that as well
        image = imageCache.object(forKey: url as AnyObject) as? UIImage
        return image
    }
}
