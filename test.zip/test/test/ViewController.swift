//
//  ViewController.swift
//  test
//
//  Created by mac on 30/05/23.
//

import UIKit

class ViewController: UIViewController {


    @IBOutlet private weak var welcomeTableView: UITableView! {
        didSet {
            welcomeTableView.delegate = self
            welcomeTableView.dataSource = self
            welcomeTableView.register(UINib(nibName: "WelcomeTableViewCell",
                                            bundle: nil),
                                      forCellReuseIdentifier: "WelcomeTableViewCell")
        }
    }

    var viewModel = WelcomeViewModel()
    let pullRefresh = UIRefreshControl()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.callWelcomeListApi()
        self.pullRefresh.addTarget(self, action: #selector(handleTopRefresh(_:)), for: .valueChanged)
        self.pullRefresh.tintColor = UIColor.blue
        welcomeTableView.addSubview(pullRefresh)
    }

    @objc
    func handleTopRefresh(_ sender: UIRefreshControl) {
        self.viewModel.offset = 1
        callWelcomeListApi()
    }
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension ViewController: UITableViewDelegate,
                               UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.getCount()
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = welcomeTableView.dequeueReusableCell(withIdentifier: "WelcomeTableViewCell",
                                                      for: indexPath) as? WelcomeTableViewCell
        cell?.selectionStyle = .none
        cell?.setCellData(data: self.viewModel.getModel(indexPath.row))
        return cell ?? WelcomeTableViewCell()
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if self.viewModel.getCellIsSelectedOrNot(indexPath.row) {
            let alert = UIAlertController(title: "Deselect", message: "Do you wants to deselect", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "yes", style: UIAlertAction.Style.default, handler: {_ in 
                self.viewModel.selectModel(indexPath.row)
                self.welcomeTableView.reloadData()
            }))
            self.present(alert, animated: true, completion: nil)
        } else {
            PopUpView.showPopupViewAlert(rightButtonAction: {
                self.viewModel.selectModel(indexPath.row)
                self.welcomeTableView.reloadData()
                return Void()
            })
            PopUpView.sharedInstance.delegate = nil
        }

    }

    func scrollViewDidEndDragging(_ scrollView: UIScrollView,
                                  willDecelerate decelerate: Bool) {
        if (scrollView.contentOffset.y + scrollView.frame.size.height) >= (scrollView.contentSize.height) {
            if viewModel.isAllDataLoaded {
                self.viewModel.offset += 1
                self.callWelcomeListApi()
            }
        }
    }
}

extension ViewController {
    func callWelcomeListApi() {
        var param = [String: Any]()
        param["offset"] = viewModel.offset
        param["limit"] = viewModel.pageLimit

        viewModel.requestWelcomeList(responseHandler: { success, status, message in
            self.pullRefresh.endRefreshing()
            self.welcomeTableView.reloadData()
        })
    }
}


