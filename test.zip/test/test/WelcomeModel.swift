//
//  WelcomeModel.swift
//  test
//
//  Created by mac on 30/05/23.
//

import Foundation
import UIKit

// MARK: - WelcomeElement
struct WelcomeModel {
    var id = ""
    var author = ""
    var width = 0
    var height = 0
    var url = ""
    var downloadURL = ""
    var isSelected = false
}

extension WelcomeModel {
    init(_ dict: [String: Any]) {
        self.id = dict.getStringValue(forKey: "id")
        self.author = dict.getStringValue(forKey: "author")
        self.width = dict.getIntValue(forKey: "width")
        self.height = dict.getIntValue(forKey: "height")
        self.url = dict.getStringValue(forKey: "url")
        self.downloadURL = dict.getStringValue(forKey: "download_url")
    }
}

// MARK: - Dictionary Supporting Extensions

extension Dictionary where Key == String {

    // MARK: To fetch string value from Dictionary
    func getStringValue(forKey key: String) -> String {
        if let value = self[key] as? String {
            return value
        } else if let value = self[key] as? Int {
            return "\(value)"
        } else if let value = self[key] as? Float {
            return "\(value)"
        } else if let value = self[key] as? Double {
            return "\(value)"
        } else if let value = self[key] {
            return "\(value)" == "<null>" ?"" :"\(value)"
        }
        return ""
    }

    // MARK: To fetch int value from Dictionary
    func getIntValue(forKey key: String) -> Int {
        if let value = self[key] as? Int {
            return value
        }
        return 0
    }

    // MARK: To fetch Array from Dictionary
    func getArrayValue(forKey key: String) -> [Any] {
        if let value = self[key] as? [Any] {
            return value
        }
        return []
    }

}
